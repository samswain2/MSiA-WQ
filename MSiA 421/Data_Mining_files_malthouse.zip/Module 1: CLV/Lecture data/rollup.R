setwd("/Users/ecm/teach/data/CLVcontest")
trans = read.csv("trans.csv")
trans$source = NULL
trans$t = as.numeric(as.Date("2005/09/01") - as.Date(trans$giftdate,"%m/%d/%Y") )/365.25
head(trans, 13)


library(ggplot2)
library(dplyr)
qplot(x=log(amt+1, base=10), data=trans, bins=30)
head(freqdist(trans$amt, T), 10)
qplot(x=as.Date(trans$giftdate,"%m/%d/%Y"), data=trans, bins=30)

summary(trans)

# make RFM as of 9/1/05
rfm = trans %>%
  filter(t>0) %>%
  group_by(id) %>%
  summarise(r=min(t), f=n(), m=sum(amt), aos=mean(amt))
head(rfm)
dim(rfm)

# create variable indicating donations in 9/1/05-8/31/06
dv = trans %>%
  filter(t<=0) %>%
  group_by(id) %>%
  summarise(targfreq=n(), targdol=sum(amt)) 
dim(dv)
head(dv)

# merge them
newrfm = left_join(rfm, dv, by="id") %>%
  mutate(targfreq = ifelse(is.na(targfreq), 0, targfreq),
         targdol=ifelse(is.na(targdol), 0, targdol))
dim(newrfm)
head(newrfm, 10)
summary(newrfm)
qplot(x=log(m+1, base=10), data=rfm, bins=30)

fit = lm(log(targdol+1) ~ log(r) + log(f) + log(m), newrfm)
summary(fit)
