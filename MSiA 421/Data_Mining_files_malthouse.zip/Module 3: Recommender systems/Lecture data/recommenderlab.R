install.packages("recommenderlab") # do this only once
library(recommenderlab)

# section 5.1
set.seed(12345)
nuser=10
nitem=10
m = matrix(
  sample(
    c(as.numeric(0:5), NA), 
    nuser*nitem, 
    replace=T, 
    prob=c(rep(.4/6,6),.6)
  ), 
  ncol=nitem, 
  dimnames=list(
      user=paste("u", 1:nuser, sep=''), 
      item=paste("i",1:nitem, sep='')
  ))
m[3,3]=1 # I want at least two ratings per user
m
is.matrix(m)
r = as(m, "realRatingMatrix")   #puts it into sparse format
r
is.matrix(r)
round(simil(m, method="cosine"), 4)
# confirm s(1,2) = 0.354246
# numerator r_1 * r_2 = 3 + 5 = 8
# simil only uses complete rows, so .3542 = 8/sqrt(51*(9+0+1)) =0.354246

rowMeans(r)
colMeans(r)
# for row 1: (3+4+4+0+4+3+1+1)/8 = 20/8 = 2.5
identical(as(r, "matrix"), m)
as(r, "matrix")   # converts it back to a matrix
as(r, "list")  # makes a list, one compoent per user in sparse format
as(r, "data.frame")  # data frame with cols for user, item, rating, sparse format

# Section 5.2 how to ipsatize/normalize
r_m = normalize(r) # each user has mean 0
r_m # note of subclass realRatingMatrix
as(r_m, "list")
round(as(r_m, "matrix"), 4)
# now confirm r_11
as(r, "list")$u1
rowMeans(r)
as(r_m, "list")$u1
# Note that 3-2.5 = 0.5, 4-2.5=1.5, etc 
# here are some plots to show sparsity
image(r, main="Raw Ratings")
image(r_m, main="Normalized Ratings")

# Section 5.3 binarize the data
r_b = binarize(r, minRating=4)
r_b # note of subclass binaryRatingMatrix
as(r_b, "matrix")
as(r, "matrix")>=4  # same true values, but does not replace NAs

fit = Recommender(r, method="RANDOM")
# assume we do not want to rerecommend items, what do we recoomend to u1? u2?
yhat = predict(fit, r, n=3)
as(yhat, "list")[1:2]
# Try this again and it should change

as(r, "matrix")
round(rowMeans(r), 2)
round(colMeans(r), 2)
# check value for i1: rbar_i1=(3+1+4+1+3+0)/6=12/6=2
round(as(r_m, "matrix"), 3)
round(colMeans(r_m), 4)
round(colMeans(r), 2)
# based on these means, what would popular recommend to u1? u2? Why?
fit = Recommender(r, method="POPULAR")
fit
yhat = predict(fit, r, n=1)  # predict top n=1 item
as(yhat, "matrix")           # note that it recommends i2 instead of i3 to u1
yhat = predict(fit, r, n=2)  # predict top n=2 items
round(as(yhat, "matrix"), 4)
names(getModel(fit))
getModel(fit)$normalize
fit = Recommender(r, method="POPULAR", parameter=list(normalize=NULL))
colMeans(r)
# now what should it recommend to u1? u2?
fit
yhat = predict(fit, r, n=1)  # predict top n=1 item
as(yhat, "matrix")           # now it recommends i3 instead of i2 to u1

#  UBCF
fit = Recommender(r, method="UBCF")
getModel(fit)
yhat = predict(fit, r)
round(as(yhat, "matrix"), 3)

#  UBCF without centering, k=3 nearest neighbors
fit = Recommender(r, method="UBCF", param=list(normalize=NULL, nn=3))
getModel(fit)
yhat = predict(fit, r, type="ratings")
as(yhat, "matrix")

rm(m, r, r_m, r_b, yhat, nuser, nitem)

#section 5.4 Jester data
data(Jester5k)
head(JesterJokes)
Jester5k
set.seed(12345)
r = sample(Jester5k, 1000)
r
as(r[1,], "list")
rowMeans(r[1,]) # find mean rating of user row 1
length(getRatings(r))  # vector of all ratings
hist(getRatings(r), breaks=100)  # histogram of all ratings
hist(getRatings(normalize(r)), breaks=100)
hist(getRatings(normalize(r, method="Z-score")), breaks=100)
hist(rowCounts(r), breaks=50)  # number jokes rated by each user
hist(colMeans(r), breaks=20)  # Avg rating each joke
image(r)

# section 5.5
recommenderRegistry$get_entries(dataType = "realRatingMatrix")
# create recommender using only popularity of items
r = Recommender(Jester5k[1:1000], method="POPULAR")
r
names(getModel(r))
getModel(r)$topN
getModel(r)$ratings
getModel(r)$normalize
getModel(r)$aggregation
getModel(r)$verbose
recom = predict(r, Jester5k[1001:1002], n=5)
recom
as(recom, "list")
JesterJokes["j89"]
recom3 = bestN(recom, n=3)
recom3
as(recom3, "list")
recom = predict(r, Jester5k[1001:1002], type="ratings")
recom
as(recom, "matrix")[,1:10]  # NA means user rated the item

# section 5.6
# use 15 items for finding NNs. A good rating one >=5
# split into test and trining, with 90% in training
set.seed(12345)
e=evaluationScheme(Jester5k[1:1000], method="split", train=.9, given=15)#, goodRating=5)
e
(r1 = Recommender(getData(e, "train"), "UBCF"))
(junk=predict(r1, getData(e, "train"), type="ratings")) # predictions for training set
(p1 = predict(r1, getData(e, "known"), type="ratings")) # known part (15 given items) test set
(junk=predict(r1, getData(e, "unknown"), type="ratings")) # unknown part (not "given") test set
(r2 = Recommender(getData(e, "train"), "IBCF"))
(r3 = Recommender(getData(e, "train"), "POPULAR"))
(r4 = Recommender(getData(e, "train"), "RANDOM"))
(r5 = Recommender(getData(e, "train"), "SVD"))
(p2 = predict(r2, getData(e, "known"), type="ratings")) 
(p3 = predict(r3, getData(e, "known"), type="ratings")) 
(p4 = predict(r4, getData(e, "known"), type="ratings")) 
(p5 = predict(r5, getData(e, "known"), type="ratings")) 
(error = rbind(
  UBCF=calcPredictionAccuracy(p1, getData(e, "unknown")),
  IBCF=calcPredictionAccuracy(p2, getData(e, "unknown")),
  POP=calcPredictionAccuracy(p3, getData(e, "unknown")),
  RAND=calcPredictionAccuracy(p4, getData(e, "unknown")),
  SVD=calcPredictionAccuracy(p5, getData(e, "unknown"))
))

rm(p1, r1, r2, e, r, recom, recom3)

# section 5.7 Evaluation of a top-N rec alg
# use 4-fold CV, match on 3 NNs
set.seed(12345) # always a good idea so that you can replicate your results
scheme = evaluationScheme(Jester5k[1:1000], method="cross", k=4, given=10, goodRating=5)
scheme
results = evaluate(scheme, method="POPULAR", type="topNList", n=c(1,3,5,10,15,20))
results
getConfusionMatrix(results)[[1]] # [1] gives the results for the four folds
avg(results)
plot(results, annotate=T);abline(0,1)  # ROC
plot(results, "prec/rec", annotate=T)

# section 5.8 Comparing recommender algorithms
set.seed(2016)
scheme = evaluationScheme(Jester5k[1:1000], method="split", train=.9, k=1, given=-5, goodRating=5)
scheme
(r1 = Recommender(getData(scheme, "train"), "UBCF"))
(junk=predict(r1, getData(scheme, "train"), type="ratings")) # predictions for training set
(p1 = predict(r1, getData(scheme, "known"), type="ratings")) # known part (15 given items) test set
(junk=predict(r1, getData(scheme, "unknown"), type="ratings")) # unknown part (not "given") test set

algorithms = list(
	"random"=list(name="RANDOM", param=NULL),
	"popular"=list(name="POPULAR", param=NULL),
	"ubcfNULL"=list(name="UBCF", param=list(nn=50,normalize=NULL)),
	"ubcf50"=list(name="UBCF", param=list(nn=50)),
	"ubcf10"=list(name="UBCF", param=list(nn=10)),
	"ibcf50"=list(name="IBCF", param=list(k=50)),
	"SVD"=list(name="SVD", param=NULL)
)
# svd should have parameter approxRank, but it gives a warning message
# run algorithms
results = evaluate(scheme, algorithms, type="topNList", n=1:30)
results
names(results)
results[[3]]
# annotate says to ad labels only for curves 1 and 3 (random, user-based)
plot(results, legend="bottomright", cex=.5)
plot(results, "prec/rec", cex=.6, legend="topleft")

# now evaluate how well they predict ratings
# run algorithms page 31
results = evaluate(scheme, algorithms, type="ratings")
results
plot(results, col=1:7)

# using 0-1 data, bottom of page 31
Jester_binary = binarize(Jester5k, minRating=5)
Jester_binary = Jester_binary[rowCounts(Jester_binary)>20]
Jester_binary
scheme_binary = evaluationScheme(Jester_binary[1:1000], method="split", train=.9, k=1, given=3)
scheme_binary
results_binary = evaluate(scheme_binary, algorithms[1:4], type="topNList", n=c(1,3,5,10,15,20))
plot(results_binary, annotate=c(1,3), legend="bottomright")
plot(results_binary, "prec/rec", annotate=c(1,3), legend="bottomright")

# section 5.9


set.seed(12345)
e = evaluationScheme(Jester5k[1:1000], method="split", train=.5, given=15)
e
r1 = Recommender(getData(e, "train"), "UBCF")
p1 = predict(r1, getData(e, "known"), type="ratings")
r1
getModel(r1)
p1
calcPredictionAccuracy(p1, getData(e, "unknown"))

r2 = Recommender(getData(e, "train"), "IBCF")
p2 = predict(r2, getData(e, "known"), type="ratings")
r2
p2
calcPredictionAccuracy(p2, getData(e, "unknown"))

set.seed(12345)
e = evaluationScheme(Jester5k[1:1000], method="cross", k=5, given=15)
e
r1 = Recommender(getData(e, "train"), "UBCF")
p1 = predict(r1, getData(e, "known"), type="ratings")
calcPredictionAccuracy(p1, getData(e, "unknown"))

# if we run this again we'll get slightly different answer
# due to different data splits (sampling variation)
calcPredictionAccuracy(p2, getData(e, "unknown"))
e = evaluationScheme(Jester5k[1:1000], method="cross", k=5, given=15)
r1 = Recommender(getData(e, "train"), "UBCF")
p1 = predict(r1, getData(e, "known"), type="ratings")
calcPredictionAccuracy(p1, getData(e, "unknown"))




set.seed(12345)  # continue using 5-fold CV
e = evaluationScheme(Jester5k[1:1000], method="cross", k=5, given=15)
doit = function(method, ...)  # write function to make life easy
{
  r1 = Recommender(getData(e, "train"), method, ...)
  p1 = predict(r1, getData(e, "known"), type="ratings")
  calcPredictionAccuracy(p1, getData(e, "unknown"))
}
doit("UBCF")
doit("UBCF", param=list(nn=10))
doit("UBCF", param=list(nn=50, normalize=NULL))
doit("UBCF", param=list(nn=50, normalize="z-score"))
doit("UBCF", param=list(nn=50, normalize="z-score", method="pearson"))

# create all combinations of 3 factors
ans = expand.grid(normalize=c("center","z-score"),
                  method=c("cosine", "pearson"),
                  nn=c(10, 25, 50))
ans$RMSE=NA
ans$MSE=NA
ans$MAE=NA
ans
for(i in 1:nrow(ans))
  ans[i, c("RMSE", "MSE", "MAE")] = doit("UBCF",
            param=list(nn=ans$nn[i],
            normalize=ans$normalize[i],
            method=ans$method[i]))
ans
cor(ans$RMSE, ans$MAE)  # measures highly correlated
fit = lm(RMSE ~ normalize+method+factor(nn), ans)  # assume no interactions
drop1(fit, test="F")
summary(fit)

# could check for two-way interactions
fit = lm(RMSE ~ (normalize+method+factor(nn))^2, ans)
drop1(fit, test="F")
with(ans, interaction.plot(nn, method, RMSE, col=1:2))

# you could use multiple replicates with different seeds
# Another variation is fractional orthogonal designs


# now illustrate DS metrics
# all jokes >=5 are "good" and others are "bad"
set.seed(12345)
scheme = evaluationScheme(Jester5k[1:1000], method="split", train=.5, given=5, goodRating=5)
scheme
algorithms = list(
  "random"=list(name="RANDOM", param=NULL),
  "popular"=list(name="POPULAR", param=NULL),
  "ubcfNULL"=list(name="UBCF", param=list(nn=50,normalize=NULL)),
  "ubcf50"=list(name="UBCF", param=list(nn=50)),
  "ubcf200"=list(name="UBCF", param=list(nn=200)),
  "ibcf50"=list(name="IBCF", param=list(k=50)),
  "svd"=list(name="SVD", param=NULL)
)
# run algorithms
results = evaluate(scheme, algorithms, type="topNList", n=1:30)
results
names(results)
results[[3]]
# annotate says to ad labels only for curves 1 and 3 (random, user-based)
plot(results, annotate=c(1,3), legend="bottomright")
plot(results, "prec/rec", annotate=3, legend="topleft")

# now evaluate how well they predict ratings
# run algorithms page 31
results = evaluate(scheme, algorithms, type="ratings")
results
plot(results, col=1:7)

# what if we have binary data?
Jester_binary = binarize(Jester5k, minRating=5)
Jester_binary = Jester_binary[rowCounts(Jester_binary)>20]
Jester_binary
scheme_binary = evaluationScheme(Jester_binary[1:1000], method="split", train=.5, given=5)
scheme_binary
results_binary = evaluate(scheme_binary, algorithms[1:4], type="topNList", n=1:30)
plot(results_binary, annotate=c(1,3), legend="bottomright")


rm(scheme, results)
