library(psych)
library(Matrix)
movies = c("Matrix", "Alien", "StarWars", "Casablanca", "Titanic")
X = matrix(
  c(1,1,1,0,0,
    3,3,3,0,0,
    4,4,4,0,0,
    5,5,5,0,0,
    0,0,0,4,4,
    0,0,0,5,5,
    0,0,0,2,2),
  byrow=T, ncol=5, dimnames = list(LETTERS[1:7], movies)
)
X
cor(X)
rankMatrix(X)
svdX = svd(X)
round(svdX$d, 4)
round(-svdX$u[,1:2], 2)
round(-t(svdX$v[,1:2]), 2)
sum(X^2)
sum(svdX$d^2)

(X = matrix(
  c(1,1,1,0,0,
    3,3,3,0,0,
    4,4,4,0,0,
    5,5,5,0,0,
    0,2,0,4,4,
    0,1,0,5,5,
    0,0,0,2,2),
  byrow=T, ncol=5, dimnames = list(LETTERS[1:7], movies)
))
cor(X)
svdX = svd(X)
round(svdX$d, 4)
round(svdX$u[,1:3], 2)
round(t(svdX$v[,1:3]), 2)
sum(X^2)
sum(svdX$d^2)
cumsum(svdX$d^2)/sum(svdX$d^2)
# Approximate X with first two dimensions
X
(Xhat = svdX$u[,1:2] %*% diag(svdX$d[1:2]) %*% t(svdX$v[,1:2]))
(Ehat = X-Xhat)
cbind(dims=1:5, Dsquared=round(svdX$d^2,4), cumDsquared=cumsum(svdX$d^2), fraction=cumsum(svdX$d^2)/sum(svdX$d^2))
sum(Xhat^2)
sum(Ehat^2)
