library(mclust)
library(lattice)
setwd("/Users/ecm/teach/MSiA421")

# do old faithful example
oldfaith = read.csv("oldfaith.csv")
str(oldfaith)

ggplot(oldfaith, aes(length)) + geom_histogram(bins=10) + geom_rug()
hist(oldfaith$length)
pdf("/Users/ecm/teach/lectures/clus/oldfaith.pdf", height=5, width=5)
densityplot(~length, data=oldfaith, n=200)
dev.off()
fit = kmeans(oldfaith, centers=2, nstart=100)
summary(fit)

fit2 = Mclust(oldfaith, G=2)
plot(fit2)
fit2$parameters
sqrt(fit2$parameters$variance$sigmasq)
fit2 = Mclust(oldfaith)
plot(fit2)
fit2$parameters



binarymix <- function(x, maxit=500, tol=.0001, dec=2, eta=.5, seed=1, printit=F)
{
  loglike <- function(x, mu, sd, eta)
    sum(log((1-eta)*dnorm(x,mu[1],sd[1])+eta*dnorm(x,mu[2],sd[2])))
  
  set.seed(seed)
  n <- length(x)
  post <- double(n)  # posterior distribution P(Y|x)
  mu <- x[sample(1:n, 2)]
  sd <- rep(sqrt(var(x)),2)
  l <- loglike(x, mu, sd, eta)
  lold <- l+2*tol
  it <- 0
  if(printit) cat("It Mu0 Mu1 Sd0 Sd1 eta loglike\n")
  if(printit) cat(it, round(c(mu, sd, eta),dec), round(l,-log10(tol)+1),"\n")
  
  while(it<maxit & abs(l-lold)>tol){
    f2 <- dnorm(x,mu[2],sd[2])
    post <- eta*f2 / ((1-eta)*dnorm(x,mu[1],sd[1]) + eta*f2)
    mu[1] <- sum(x*(1-post))/sum(1-post)
    mu[2] <- sum(x*post)/sum(post)
    sd[1] <- sqrt(sum((x-mu[1])^2*(1-post))/sum(1-post))
    sd[2] <- sqrt(sum((x-mu[2])^2*post)/sum(post))
    eta <- mean(post)
    lold <- l
    l <- loglike(x, mu, sd, eta)
    it <- it+1
    if(printit) cat(it, round(c(mu, sd, eta),dec), round(l,-log10(tol)+1),"\n")
  }
  if(abs(l-lold)<tol){
    cat("Converged in ",it,"iterations\n")
    cat("-2*loglike=",round(-2*l,-log10(tol)+1),"\n")
    cat("(Mean, sd, eta) = ", round(c(mu,sd,eta), dec), "\n")
  } else cat("Did not converge in ", it, "iterations\n")
  invisible(list(mu=mu, sd=sd, eta=eta, post=post, dev=-2*l))
}

binarymix(oldfaith$length, dec=4)

################################################################
# Do math example page 44
set.seed(12345)
x = c(rnorm(100,0,0.5), rnorm(200,3,1))
y = c(rep(0,100), rep(1,200))
pdf("/Users/ecm/teach/lectures/clus/fmm1.pdf", height=5, width=5)
print(densityplot(~x|as.factor(y), layout=c(1,2), n=200, width=1.5))
dev.off()
# using Trellis functions
pdf("/Users/ecm/teach/lectures/clus/fmm2.pdf", height=5, width=5)
print(densityplot(~x, n=200, width=1.5))
dev.off()

# find solution with binarymix
ans = binarymix(x, seed=12345, maxit=200, dec=4)
ans$sd^2

# find solution with Mclust
fit = Mclust(x, G=2)
plot(fit)
pdf("/Users/ecm/teach/lectures/clus/fmm3.pdf", height=5, width=5)
plot(fit, what="classification", main="Classification")
dev.off()
pdf("/Users/ecm/teach/lectures/clus/fmm4.pdf", height=5, width=9)
par(mfrow=c(1,2))
plot(fit, what="uncertainty", main="Uncertainty")
plot(fit, what="density", main="Density")
dev.off()
fit$parameters

fit2 = kmeans(x, 2, nstart=100)
summary(fit2)

x = seq(-4, 5, length=200)
eta0f0 = dnorm(x, 0, .5)/3
eta1f1 = 2*dnorm(x, 3, 1)/3
f = eta0f0 + eta1f1
pdf("/Users/ecm/teach/lectures/clus/fmm5.pdf", height=6, width=9)
par(mfrow=c(2,1))
plot(x, f, type="l", ylab="f_k(x)")
lines(x, eta0f0, lty=2, col=2)
lines(x, eta1f1, lty=4, col=4)
legend(-4, .25, c("f(x)", "f0(x)", "f1(x)"), lty=c(1,2,4), col=c(1,2,4))
plot(x, eta0f0/f, type="l", ylab="P(Y|x)", lty=2, col=2)
lines(x, eta1f1/f, lty=4, col=4)
legend(2, .8, c("P(Y=0|x)", "P(Y=1|x)"), lty=c(2,4), col=c(2,4))
par(mfrow=c(1,1))
dev.off()

# non-spherical mixture on page 51
sigma = matrix(c(1,rep(.8,2),1), nrow=2)
sigma
A = chol(sigma)
t(A) %*% A   # should give sigma
set.seed(12345)
Z = matrix(rnorm(200), nrow=100)
X = Z %*% A
dat = data.frame(
  x1 = c(rnorm(100), X[,1]+2),
  x2 = c(rnorm(100), X[,2]),
  y = c(rep(1,100), rep(2,100))
)
fit = kmeans(dat[,1:2], 2, nstart=100)
plot(dat[,1:2], col=dat$y, pch=15+dat$y)
points(dat[fit$cluster!=dat$y, 1:2], cex=2)
points(fit$centers, pch=3, cex=3)

fit = Mclust(dat[,1:2], G=2)
pdf("/Users/ecm/teach/lectures/clus/breakkm9.pdf", height=5, width=5)
plot(fit, what="uncertainty", main="uncertainty")
dev.off()
pdf("/Users/ecm/teach/lectures/clus/breakkm10.pdf", height=5, width=5)
plot(fit, what="density", main="density")
dev.off()

fit$parameters
cov2cor(fit$parameters$variance$sigma[,,1])
cov2cor(fit$parameters$variance$sigma[,,2])

# EII
pdf("/Users/ecm/teach/lectures/clus/eii.pdf", height=4, width=4)
plot(c(1,3,4), c(1,4,2), cex=6, xlim=c(0,5), ylim=c(0,5), xlab="x1", ylab="x2")
text(2,3,"EII", cex=2)
dev.off()

#VII
pdf("/Users/ecm/teach/lectures/clus/vii.pdf", height=4, width=4)
plot(c(1,3,4), c(1,4,2), cex=c(2,6,8), xlim=c(0,5), ylim=c(0,5), xlab="x1", ylab="x2")
text(2,3,"VII", cex=2)
dev.off()

#EEI
library(plotrix)
pdf("/Users/ecm/teach/lectures/clus/eei.pdf", height=4, width=4)
plot(c(1,3,4), c(1,4,2), cex=c(2,6,8), xlim=c(0,5), ylim=c(0,5), xlab="x1", ylab="x2", type="n")
draw.ellipse(1, 1, a=.3, b=.6)
draw.ellipse(3, 4, a=.3, b=.6)
draw.ellipse(4, 2, a=.3, b=.6)
text(2,3,"EEI", cex=2)
dev.off()

#VEI
pdf("/Users/ecm/teach/lectures/clus/vei.pdf", height=4, width=4)
plot(c(1,3,4), c(1,4,2), cex=c(2,6,8), xlim=c(0,5), ylim=c(0,5), xlab="x1", ylab="x2", type="n")
draw.ellipse(1, 1, a=.3, b=.6)
draw.ellipse(3, 4, a=.1, b=.2)
draw.ellipse(4, 2, a=.2, b=.4)
text(2,3,"VEI", cex=2)
dev.off()

#VVI
pdf("/Users/ecm/teach/lectures/clus/vvi.pdf", height=4, width=4)
plot(c(1,3,4), c(1,4,2), cex=c(2,6,8), xlim=c(0,5), ylim=c(0,5), xlab="x1", ylab="x2", type="n")
draw.ellipse(1, 1, a=.3, b=.6)
draw.ellipse(3, 4, b=.1, a=.2)
draw.ellipse(4, 2, a=.2, b=.4)
text(2,3,"VVI", cex=2)
dev.off()

# newspaper example page 52
np2 = read.table("/Users/ecm/teach/421/dat/np2.dat", header=T)
fit = Mclust(np2, G=5)
pdf("/Users/ecm/teach/lectures/clus/npmixed.pdf", height=7, width=7)
plot(fit, what="classification")
dev.off()
x

