summary.kmeans = function(fit) 
{
  p = ncol(fit$centers)
  K = nrow(fit$centers)
  n = sum(fit$size)
  xbar = t(fit$centers)%*%fit$size/n
  print(data.frame(
    n=c(fit$size, n),
    Pct=(round(c(fit$size, n)/n,2)),
    round(rbind(fit$centers, t(xbar)), 2),
    RMSE = round(sqrt(c(fit$withinss/(p*(fit$size-1)), fit$tot.withinss/(p*(n-K)))), 4)
  ))
  cat("SSE=", fit$tot.withinss, "; SSB=", fit$betweenss, "; SST=", fit$totss, "\n")
  cat("R-Squared = ", fit$betweenss/fit$totss, "\n")
  cat("Pseudo F = ", (fit$betweenss/(K-1))/(fit$tot.withinss/(n-K)), "\n\n");
  invisible(list(Rsqr=fit$betweenss/fit$totss, F=(fit$betweenss/(K-1))/(fit$tot.withinss/(n-K))))
}

plot.kmeans = function(fit,boxplot=F)
{
  require(lattice)
  p = ncol(fit$centers)
  k = nrow(fit$centers)
  plotdat = data.frame(
    mu=as.vector(fit$centers),
    clus=factor(rep(1:k, p)),
    var=factor( 0:(p*k-1) %/% k, labels=colnames(fit$centers))
  )
  print(dotplot(var~mu|clus, data=plotdat,
                panel=function(...){
                  panel.dotplot(...)
                  panel.abline(v=0, lwd=.1)
                },
                layout=c(k,1),
                xlab="Cluster Mean"
  ))
  invisible(plotdat)
}


# newspaper example
np2 = read.table("/Users/ecm/teach/MSiA421/dat/np2.dat", header=T)
set.seed(12345) 
fit = kmeans(np2, 5, 100, 100)
names(fit)
summary(fit)
sum(fit$withinss)
fit$tot.withinss
cbind(np2, cluster=fit$cluster) %>%
  group_by(cluster) %>%
  summarize(n=n(), SDtime=sd(time), SDsections=sd(sections))


# make image plot
setwd("/Users/ecm/prose/sasltv/clus/")
np = read.table("np.dat", header=T)
np2 = read.table("np2.dat", header=T)
npxlab="Number Hours/Week"
npylab="Number Sections"

# make image/contour plot
library(akima)
np.smooth = with(np, interp(time, sections, sqrt(count),
                            xo=seq(0, 7, length=60), yo=seq(0,7, length=60)))
pdf("/Users/ecm/teach/lectures/clus/npimage.pdf", height=4, width=3.5)
image(np.smooth, col=gray((32:0)/32), xlab=npxlab, ylab=npylab)
contour(np.smooth, levels=2:16, add=T)
dev.off()

names(fit)
fit$cluster[1:10]   # cluster assignments
fit$centers   # cluster means
fit$withinss # within cluster sums of squares
sum(fit$withinss)  # find objective function value SSE
fit$size  # counts, same as table(fit$cluster)
npxlab = "Number Hours/Week"
npylab = "Number Sections"
pdf("/Users/ecm/teach/lectures/clus/npscat.pdf", height=4, width=4)
plot(jitter(np2$time), jitter(np2$sections), col=fit$cluster, pch=16, cex=.5,
     xlab=npxlab, ylab=npylab)
points(fit$centers, pch=3, cex=4)
dev.off()

summary(fit)
plot(fit)

# trade show example
dat = read.csv("/Users/ecm/teach/data/tradeshow.csv")
set.seed(12345)
fit = kmeans(dat, 3, 100, 100)
summary(fit)
pdf("/Users/ecm/teach/lectures/clus/promat.pdf", height=4, width=4)
plot(jitter(dat$buy0), jitter(dat$social0), col=fit$cluster, pch=15+fit$cluster)
points(fit$centers[,c(1,2)], pch=3, cex=3, col=1:3)
dev.off()
pdf("/Users/ecm/teach/lectures/clus/promat2.pdf", height=4, width=4)
plot(jitter(dat$buy0), jitter(dat$educ0), col=fit$cluster, pch=15+fit$cluster)
points(fit$centers[,c(1,3)], pch=3, cex=3, col=1:3)
dev.off()
pdf("/Users/ecm/teach/lectures/clus/promat3.pdf", height=4, width=4)
plot(jitter(dat$social0), jitter(dat$educ0), col=fit$cluster, pch=15+fit$cluster)
points(fit$centers[,c(2,3)], pch=3, cex=3, col=1:3)
dev.off()
pdf("/Users/ecm/teach/lectures/clus/promat4.pdf", height=3, width=4)
print(plot(fit))
dev.off()

# theater example
theater = read.csv("/Users/ecm/prose/sasltv/clus/theater.csv")
summary(theater)
theater$age2 = theater$age*5 + 20  # transform response cat to age in yrs
Ztheater = data.frame(lapply(theater[,1:5], scale, scale=T)) # standardize data

set.seed(12345)  # not necessary, but assures that you get same starting values
fit.th3 = kmeans(Ztheater, 3, nstart=100)
fit.th4 = kmeans(Ztheater, 4, nstart=100)
fit.th5 = kmeans(Ztheater, 5, nstart=100)
summary(fit.th3)
#pdf("/Users/ecm/teach/lectures/clus/theater1.pdf", height=4, width=5)
plot(fit.th3)
#dev.off()
summary(fit.th4)
plot(fit.th4)
(a=table(fit.th3$cluster, fit.th4$cluster))
round(prop.table(a,1), 2)

# now profile the clusters
theater$clus3 = factor(fit.th3$cluster, levels=1:3, 
      labels=c("Barriers", "ThBad", "ThGood"))
# compare ages
with(theater, tapply(age2, clus3, mean, na.rm=T))
fit = aov(age2 ~ clus3, theater)
summary(fit)
TukeyHSD(fit)

# now do education
with(theater, tapply(educ, clus3, mean, na.rm=T))
fit = aov(educ ~ clus3, theater)
summary(fit)
TukeyHSD(fit)

# now do income
with(theater, tapply(income, clus3, mean, na.rm=T))
fit = aov(income ~ clus3, theater)
summary(fit)
TukeyHSD(fit)

# county
(ans=with(theater, table(clus3, cnty)))
round(prop.table(ans,1), 2)
round(table(theater$cnty)/nrow(theater), 2)
chisq.test(ans)
round(chisq.test(ans)$stdres, 2)

# number clusters np example
F = double(7)
for(K in 2:8){
  set.seed(12345)
  F[K-1] = summary(
    kmeans(np2, K, nstart=100))$F
}
pdf("/Users/ecm/teach/lectures/clus/npnumclus.pdf", height=4, width=4)
plot(2:8, F, type="b",
     xlab="Number Clusters K")
dev.off()


# silhouette
library(cluster)
data(ruspini)
set.seed(12345)
fit = kmeans(ruspini, 4, nstart=50)
summary(fit)

pdf("/Users/ecm/teach/lectures/clus/ruspini1.pdf", height=4, width=4)
plot(ruspini, col=fit$cluster)
points(fit$centers, pch=3, col=1:4, cex=3)
dev.off()
si2 = silhouette(fit$cluster, dist(ruspini, "euclidean"))
summary(si2)
pdf("/Users/ecm/teach/lectures/clus/ruspini2.pdf", height=8, width=4)
plot(si2, col = 1:4)
dev.off()
plot(si2, nmax= 80, cex.names=0.6)

# try K=2-6 on Ruspini
F = double(5)
sse = double(5)
si = double(5)
par(mfrow=c(1,2))
for(k in 2:6){
  set.seed(12345)
  fit = kmeans(ruspini, k, nstart=50)
  F[k-1] = (fit$betweenss/(k-1))/(fit$tot.withinss/(nrow(ruspini)-k))
  sse[k-1] = fit$tot.withinss
  plot(ruspini, col=fit$cluster, pch=fit$cluster)
  points(fit$centers, pch=3, col=1:k, cex=3) # cluster centers
  si2 = silhouette(fit$cluster, dist(ruspini, "euclidean"))
  si[k-1] = summary(si2)$avg.width
  plot(si2, col=1:k)
  x=scan()
}
pdf("/Users/ecm/teach/lectures/clus/ruspini3.pdf", height=5, width=9)
par(mfrow=c(1,2))
plot(2:6, F, type="b")
plot(2:6, sse, type="b")
par(mfrow=c(1,1))
dev.off()
pdf("/Users/ecm/teach/lectures/clus/ruspini4.pdf", height=4, width=4)
plot(2:6, si, type="b")
dev.off()

# number clusters np example
si = double(7)
for(K in 2:8){
  set.seed(12345)
  fit=kmeans(np2, K, nstart=100)
  si2 = silhouette(fit$cluster, dist(np2, "euclidean"))
  si[K-1] = summary(si2)$avg.width
}
pdf("/Users/ecm/teach/lectures/clus/NPsilhouette.pdf", height=5, width=5)
plot(2:8, si, type="b", main="NP")
dev.off()

# theater
F = double(5)
si = double(5)
for(K in 2:6){
  set.seed(12345)
  fit=kmeans(Ztheater, K, nstart=50)
  F[K-1] = (fit$betweenss/(K-1))/(fit$tot.withinss/(nrow(Ztheater)-K))
  si2 = silhouette(fit$cluster, dist(Ztheater, "euclidean"))
  si[K-1] = summary(si2)$avg.width
}
pdf("/Users/ecm/teach/lectures/clus/TheaterSil.pdf", height=5, width=9)
par(mfrow=c(1,2))
plot(2:6, si, type="b", main="Theater")
plot(2:6, F, type="b", main="Theater")
dev.off()

# k-means sensitive to starting values: np example
pdf("/Users/ecm/teach/lectures/clus/npmultseed.pdf", height=4, width=9)
par(mfrow=c(1,2))
plot(np2, type="n")

n=100 # generate 100 different solutions
mse = double(n)
set.seed(12345)
minmse = 99999
for(i in 1:n){
  fit = kmeans(np2, 5, iter.max=100)
  points(fit$centers[,1], fit$centers[,2])
  mse[i] = sum(fit$withinss)/nrow(np2)
  if(mse[i]<minmse){
    fitbest=fit
    minmse=mse[i]
  }
}
# best solution from 100 runs
sum(fitbest$withinss)/nrow(np2)
points(fitbest$centers[,1], fitbest$centers[,2], pch=2, cex=2, col=2)

hist(mse)
dev.off()
summary(mse)


#Gaussian Mixutre
set.seed(12345)
dat = data.frame(
  x1 = c(rnorm(100), rnorm(100)+3),
  x2 = c(rnorm(200)),
  y = c(rep(1,100), rep(2,100))
)
pdf("/Users/ecm/teach/lectures/clus/kmbreak1.pdf", height=5, width=5)
plot(dat[,1:2], col=dat$y, pch=15+dat$y)
dev.off()

fit = kmeans(dat[,1:2], 2, nstart=100)
summary(fit)
table(fit$cluster, dat$y)
pdf("/Users/ecm/teach/lectures/clus/kmbreak2.pdf", height=5, width=5)
plot(dat[,1:2], col=fit$cluster, pch=15+fit$cluster)
wrong = (fit$cluster!=dat$y)
points(dat[wrong, 1:2], cex=2)
points(fit$centers, pch=3, cex=3)
dev.off()

# simulate multicollinearity
dat$x3 = dat$x2
dat$x4 = dat$x2
dat$x5 = dat$x2
fit2 = kmeans(dat[,-3], 2, nstart=100)
summary(fit2)
pdf("/Users/ecm/teach/lectures/clus/kmbreak3.pdf", height=5, width=5)
plot(dat[,1:2], col=fit2$cluster, pch=15+fit$cluster)
points(fit2$centers, pch=3, cex=3)
wrong = (fit2$cluster!=dat$y)
points(dat[wrong, 1:2], cex=2)
dev.off()

# simulate incommensurate units
dat$x2 = 2*dat$x2
fit2 = kmeans(dat[,1:2], 2, nstart=100)
summary(fit2)
pdf("/Users/ecm/teach/lectures/clus/kmbreak4.pdf", height=5, width=5)
plot(dat[,1:2], col=fit2$cluster, pch=15+fit2$cluster, ylab="2*x2")
points(fit2$centers, pch=3, cex=3)
dev.off()

# unequal sizes or variances
set.seed(12345)
dat = data.frame(
  x1 = c(rnorm(100), rnorm(50)+3),
  x2 = c(rnorm(150)),
  y = c(rep(1,100), rep(2,50)))

fit = kmeans(dat[,1:2], 2, nstart=100)
pdf("/Users/ecm/teach/lectures/clus/kmbreak5.pdf", height=5, width=5)
plot(dat[,1:2], col=dat$y, pch=15+dat$y)
points(dat[fit$cluster==dat$y, 1:2], cex=2)
points(fit$centers, pch=3, cex=3)
dev.off()
summary(fit)

# k-means assumes equal variance across groups.  What happens if we reduce the variance in group 2?
set.seed(12345)
dat = data.frame(
  x1 = c(rnorm(100), rnorm(100)/3+2),
  x2 = c(rnorm(100), rnorm(100)/3),
  y = c(rep(1,100), rep(2,100)))

fit = kmeans(dat[,1:2], 2, nstart=100)
pdf("/Users/ecm/teach/lectures/clus/kmbreak6.pdf", height=5, width=5)
plot(dat[,1:2], col=fit$cluster, pch=15+fit$cluster)
points(dat[fit$cluster!=dat$y, 1:2], cex=2)
points(fit$centers, pch=3, cex=3)
dev.off()
summary(fit)

# k-means wants all clusters to have the same shape.  Let's see what happens if they don't.
sigma = matrix(c(1,rep(.8,2),1), nrow=2)
A = chol(sigma)
t(A) %*% A   # should give sigma
set.seed(12345)
Z = matrix(rnorm(200), nrow=100)
X = Z %*% A
dat = data.frame(
  x1 = c(rnorm(100), X[,1]+2),
  x2 = c(rnorm(100), X[,2]),
  y = c(rep(1,100), rep(2,100))
)
fit = kmeans(dat[,1:2], 2, nstart=100)
pdf("/Users/ecm/teach/lectures/clus/kmbreak7.pdf", height=5, width=5)
plot(dat[,1:2], col=dat$y, pch=15+dat$y)
points(dat[fit$cluster!=dat$y, 1:2], cex=2)
points(fit$centers, pch=3, cex=3)
dev.off()
summary(fit)

# Here's a preview of finite mixtures
install.packages("mclust")
library(mclust)
fit2 = Mclust(dat[,1:2], G=2)
pdf("/Users/ecm/teach/lectures/clus/kmbreak8.pdf", height=5, width=5)
plot(fit2, what="classification")
dev.off()
fit2$parameters$pro
fit2$parameters$mean
write.csv(dat, file="/Users/ecm/teach/data/nonsphereclus.csv", row.names=F)
# European example
eur = as.dist(read.csv("/Users/ecm/teach/MSiA421/dat/europe.csv"))
fit = hclust(eur, method="average")
#pdf("/Users/ecm/teach/lectures/clus/euraverage.pdf", height=5, width=5)
plot(fit, main="Average Linkage")
dev.off()
fit$merge

